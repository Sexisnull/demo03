package com.gsww.icmp.controller;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.web.context.ContextLoaderListener;

import com.hanweb.jis.expansion.webservice.Constants;

public class ListenerClass extends ContextLoaderListener implements ServletContextListener  {
	@Override
	public void contextInitialized(ServletContextEvent paramServletContextEvent) {
		String sysPath = "";
		sysPath = this.getClass().getResource("/").getPath().replace("/WEB-INF/classes/", "");
//		if(sysPath.indexOf("/") == 0){
//			sysPath = sysPath.replaceFirst("/", "");
//		}
		Constants.setSysPath(sysPath);
	}
	@Override
	public void contextDestroyed(ServletContextEvent paramServletContextEvent) {
	}
}