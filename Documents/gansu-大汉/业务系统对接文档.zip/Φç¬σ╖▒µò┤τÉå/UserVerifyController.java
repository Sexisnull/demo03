package com.gsww.icmp.controller.sso;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gsww.icmp.entity.sys.SysUserSession;
import com.gsww.icmp.service.sso.UserVerifyService;

/**
 * 
 * 
 * <p>Copyright: Copyright (c) 2011</p>
 * <p>公司名称 : 中国电信甘肃万维公司</p>
 * <p>作者: @author 冯鹏
 * <p>创建时间 : 2016-3-4
 * <p>项目名称 : icmp-web
 * <p>包名 :com.gsww.icmp.controller.sso
 * <p>类名 :UserVerifyController.java
 * <p>类描述 :单点登录中验证用户
 * 测试:/interface/jis/singlelogin.jsp?loginuser=统一&loginpass=111111&groupcode=testjisdept
 */
@Controller
@RequestMapping(value="/interface")
public class UserVerifyController {
	@Autowired
	private UserVerifyService userVerifyService;

	@RequestMapping(value="/singlelogin", produces="application/json;charset=UTF-8")
	public @ResponseBody String UserLogin(HttpServletRequest request,
			HttpServletResponse response)throws Exception{
		//接收参数@ResponseBody String getAreaInfoList(HttpServletRequest request)
		String loginuser = request.getParameter("loginuser");//用户名（简称）
		String loginpass = request.getParameter("loginpass"); //密码
		String groupcode = request.getParameter("groupcode"); //机构编码 （明文）
		System.out.println("(reciver)--------interface/singlelogin:loginuser=" + loginuser + ";loginpass=" + loginpass + ";groupcode="+groupcode);

//		String path = request.getContextPath();
//		String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path + "/";		
		String resMap = "";
		//判断参数合法性
		if(loginuser == null || "".equals(loginuser)){
			resMap = "{\"ret\":\"3\",\"msg\":\"用户名不能为空！\"}";
			//response.sendRedirect(basePath + "login.jsp");
		}
		else if(loginpass == null || "".equals(loginpass)){
			resMap = "{\"ret\":\"3\",\"msg\":\"密码不能为空！\"}";
			//response.sendRedirect(basePath + "login.jsp");
		}
		else if(groupcode == null || "".equals(groupcode)){
			resMap = "{\"ret\":\"3\",\"msg\":\"机构编码不能为空！\"}";
			//response.sendRedirect(basePath + "login.jsp");
		}
		else{
			try {
				loginuser = java.net.URLDecoder.decode(loginuser,"UTF-8");
				loginpass = java.net.URLDecoder.decode(loginpass,"UTF-8");
				groupcode = java.net.URLDecoder.decode(groupcode,"UTF-8");
				System.out.println("(service)--------interface/singlelogin:loginuser=" + loginuser + ";loginpass=" + loginpass + ";groupcode="+groupcode);
				SysUserSession sysUserSession = userVerifyService.userLogin(loginuser, loginpass, groupcode);
				if (sysUserSession != null && !"".equals(sysUserSession)) {
					request.getSession().setAttribute("sysUserSession",sysUserSession);
					if("2".equals(sysUserSession.getHomeAccess())){
						resMap = "{\"ret\":\"2\",\"msg\":\"登录成功！\"}";
					}
					else{
						resMap = "{\"ret\":\"1\",\"msg\":\"登录成功！\"}";
					}
					System.out.println("(success)--------interface/singlelogin:loginuser=" + loginuser + ";loginpass=" + loginpass + ";groupcode="+groupcode);
				}
				else{
					resMap = "{\"ret\":\"3\",\"msg\":\"用户名或密码错误！\"}";
				}
			} catch (Exception e) {
				resMap = "{\"ret\":\"3\",\"msg\":\""+e.getMessage()+"\"}";
				//response.getWriter().write(JSONObject.toJSONString(resMap));
			}			
		}
		return resMap;
//		System.out.println(Convert.getAlterScript(strAlert));
//		String result = "main/init";
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		//判断参数合法性
//		if(loginuser == null || "".equals(loginuser)){
//			return result;
//		}
//		if(loginpass == null || "".equals(loginpass)){
//			return result;
//		}
//		if(groupcode == null || "".equals(groupcode)){
//			return result;
//		}
//		try {
//			SysUserSession sysUserSession = userVerifyService.userLogin(loginuser, loginpass, groupcode);
//			if (sysUserSession != null && !"".equals(sysUserSession)) {
//				request.getSession().setAttribute("sysUserSession",sysUserSession);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			resMap.put("ret", "3");
//			resMap.put("msg", "系统错误！");
//			response.getWriter().write(JSONObject.toJSONString(resMap));
//		}
	}
}