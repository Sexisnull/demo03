package com.gsww.icmp.entity.single;
/**
 * 后台机构
 * @author chen
 *
 */
public class InnerGroup {
	/**
	 * ID
	 */
	private String id = "";
	/**
	 * 机构编码
	 */
	private String groupCode = "";
	/**
	 * 机构名称
	 */
	private String groupName = "";
	/**
	 * 父机构ID
	 */
	private String parCode = "";
	/**
	 * 机构全名属性名称
	 */
	private String allName = "";
	/**
	 * 机构节点类型属性名称
	 */
	private String nodeType = "";
	/**
	 * 组织机构代码属性名称
	 */
	private String orgCode = "";
	/**
	 * 组织机构类型属性名称
	 */
	private String orgType = "";
	/**
	 * 区域类型属性名称
	 */
	private String areaType = "";
	/**
	 * 区域编码属性名称
	 */
	private String areaCode = "";
	/**
	 * 机构后缀属性名称
	 */
	private String suffix = "";
	/**
	 * 排序号属性名称
	 */
	private String orderId = "";
	
	/**
	 * 无参构造函数（一定要有不然JIS调用不到）
	 */
	public InnerGroup() {
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getParCode() {
		return parCode;
	}

	public void setParCode(String parCode) {
		this.parCode = parCode;
	}

	public String getAllName() {
		return allName;
	}

	public void setAllName(String allName) {
		this.allName = allName;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getAreaType() {
		return areaType;
	}

	public void setAreaType(String areaType) {
		this.areaType = areaType;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
